from survey.service import SurveyService
from map.controller import MapController

class SurveyPanel:
    def __init__(self):
        self.service = SurveyService()
        self.map = MapController()

    def open_survey(self, survey_id):
        print("Opening survey:", survey_id)
        # placeholder: would fetch geometry and focus
        self.map.focus_geometry(f"survey:{survey_id}")
