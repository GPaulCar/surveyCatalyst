class DetailsPanel:
    def show(self, item):
        print("Details:", item)
